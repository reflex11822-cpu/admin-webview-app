# Keep WebView JavaScript interfaces working in release/minified builds.
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.mazaglive.adminpanel.** { *; }
