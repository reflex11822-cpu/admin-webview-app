import 'package:flutter/material.dart';

import 'app_config.dart';
import 'app_theme.dart';
import 'webview_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const AdminPanelApp());
}

class AdminPanelApp extends StatelessWidget {
  const AdminPanelApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: AppConfig.appName,
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      // Follows the device's system setting; switches automatically if the
      // user toggles system dark mode while the app is open.
      themeMode: ThemeMode.system,
      home: const WebViewScreen(),
    );
  }
}

// -----------------------------------------------------------------------
// Login persistence note:
// Android's system WebView (which webview_flutter uses under the hood)
// persists cookies and local storage to disk automatically via its own
// CookieManager, exactly like Chrome does. As long as the admin panel sets
// a long-lived session cookie, the user will stay logged in across app
// restarts with no extra code required here. Do NOT call
// WebViewCookieManager().clearCookies() anywhere unless you intend to log
// the user out.
// -----------------------------------------------------------------------
