import 'dart:io';

import 'package:device_info_plus/device_info_plus.dart';
import 'package:dio/dio.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

/// Downloads a file triggered from inside the WebView (invoices, exports,
/// receipts, images, etc.), saves it to the device's Downloads folder, and
/// opens it with whatever app the user has installed for that file type.
class DownloadHelper {
  DownloadHelper._();

  static final Dio _dio = Dio();

  static Future<void> download({
    required String url,
    required void Function(String message) onStatus,
  }) async {
    try {
      // Android 13+ no longer needs WRITE_EXTERNAL_STORAGE for app-scoped
      // downloads, but we request it defensively on older OS versions.
      if (Platform.isAndroid) {
        final info = await _androidSdkInt();
        if (info < 33) {
          final status = await Permission.storage.request();
          if (!status.isGranted) {
            onStatus('Storage permission denied. Cannot download file.');
            return;
          }
        }
      }

      final dir = await _downloadsDirectory();
      final fileName = _fileNameFromUrl(url);
      final savePath = '${dir.path}/$fileName';

      onStatus('Downloading $fileName…');

      await _dio.download(
        url,
        savePath,
        onReceiveProgress: (received, total) {
          if (total > 0) {
            final pct = (received / total * 100).toStringAsFixed(0);
            onStatus('Downloading $fileName… $pct%');
          }
        },
      );

      onStatus('Saved $fileName');
      await OpenFilex.open(savePath);
    } catch (e) {
      onStatus('Download failed: $e');
    }
  }

  static Future<Directory> _downloadsDirectory() async {
    if (Platform.isAndroid) {
      // Public Downloads directory so files are visible outside the app.
      final dir = Directory('/storage/emulated/0/Download');
      if (await dir.exists()) return dir;
      return (await getExternalStorageDirectory())!;
    }
    return getApplicationDocumentsDirectory();
  }

  static String _fileNameFromUrl(String url) {
    final uri = Uri.parse(url);
    var name = uri.pathSegments.isNotEmpty ? uri.pathSegments.last : '';
    if (name.isEmpty) {
      name = 'download_${DateTime.now().millisecondsSinceEpoch}';
    }
    return name;
  }

  static Future<int> _androidSdkInt() async {
    try {
      final info = await DeviceInfoPlugin().androidInfo;
      return info.version.sdkInt;
    } catch (_) {
      // Default to a modern SDK if it cannot be determined, which skips the
      // legacy storage-permission request on newer devices.
      return 33;
    }
  }
}
