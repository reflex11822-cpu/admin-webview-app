/// Central configuration for the app.
///
/// Change these values if the admin panel URL or branding ever changes —
/// nothing else in the codebase needs to be touched.
class AppConfig {
  AppConfig._();

  /// The admin panel that is loaded inside the WebView.
  static const String homeUrl = 'https://admin-pro-mazag.mazaglive.com/';

  /// Requests to any host other than this (and its subdomains) that are not
  /// in [externalAllowList] are opened in an external browser instead of
  /// inside the WebView. Keeps the app "single purpose" and prevents users
  /// from browsing away to arbitrary sites inside the app shell.
  static const String allowedHost = 'admin-pro-mazag.mazaglive.com';

  /// Extra hosts that should still open *inside* the app (e.g. an SSO/login
  /// provider, a payment gateway, or a CDN the panel depends on). Add hosts
  /// here as needed.
  static const List<String> allowedSubHosts = <String>[
    'mazaglive.com',
  ];

  /// File extensions that should be treated as downloads rather than
  /// navigated to inside the WebView.
  static const List<String> downloadableExtensions = <String>[
    'pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'ppt', 'pptx',
    'zip', 'rar', '7z', 'apk',
    'jpg', 'jpeg', 'png', 'gif', 'webp', 'svg',
    'mp4', 'mov', 'avi',
  ];

  static const String appName = 'MazagLive Admin';
}
