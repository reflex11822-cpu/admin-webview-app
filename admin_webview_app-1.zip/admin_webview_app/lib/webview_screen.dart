import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';

import 'app_config.dart';
import 'download_helper.dart';

class WebViewScreen extends StatefulWidget {
  const WebViewScreen({super.key});

  @override
  State<WebViewScreen> createState() => _WebViewScreenState();
}

class _WebViewScreenState extends State<WebViewScreen> {
  late final WebViewController _controller;
  double _loadProgress = 0;
  bool _isLoading = true;
  bool _hasError = false;
  bool _isOffline = false;
  String? _statusMessage;
  StreamSubscription<List<ConnectivityResult>>? _connectivitySub;

  @override
  void initState() {
    super.initState();
    _setupController();
    _watchConnectivity();
  }

  @override
  void dispose() {
    _connectivitySub?.cancel();
    super.dispose();
  }

  void _watchConnectivity() {
    _connectivitySub =
        Connectivity().onConnectivityChanged.listen((results) {
      final offline = results.every((r) => r == ConnectivityResult.none);
      if (offline != _isOffline && mounted) {
        setState(() => _isOffline = offline);
      }
    });
  }

  void _setupController() {
    final controller = WebViewController();

    controller
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Theme.of(context).scaffoldBackgroundColor)
      // Grants camera/microphone access requested by the web page itself
      // (e.g. a video-call widget or a "take photo" web component).
      ..setOnPlatformPermissionRequest((request) async {
        final types = request.types;
        final needsCamera = types.contains(WebViewPermissionResourceType.camera);
        final needsMic =
            types.contains(WebViewPermissionResourceType.microphone);

        final statuses = <Permission, PermissionStatus>{};
        if (needsCamera) {
          statuses[Permission.camera] = await Permission.camera.request();
        }
        if (needsMic) {
          statuses[Permission.microphone] =
              await Permission.microphone.request();
        }

        final allGranted =
            statuses.values.every((s) => s.isGranted) || statuses.isEmpty;
        if (allGranted) {
          request.grant();
        } else {
          request.deny();
        }
      })
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (url) {
            if (!mounted) return;
            setState(() {
              _isLoading = true;
              _hasError = false;
            });
          },
          onPageFinished: (url) {
            if (!mounted) return;
            setState(() => _isLoading = false);
          },
          onProgress: (progress) {
            if (!mounted) return;
            setState(() => _loadProgress = progress / 100);
          },
          onWebResourceError: (error) {
            // Ignore sub-resource errors (ads, fonts, etc.) and only show
            // the error screen for the main frame failing to load.
            if (error.isForMainFrame ?? true) {
              if (!mounted) return;
              setState(() {
                _hasError = true;
                _isLoading = false;
              });
            }
          },
          onNavigationRequest: (request) => _handleNavigation(request),
        ),
      );

    if (controller.platform is AndroidWebViewController) {
      final androidController = controller.platform as AndroidWebViewController;

      // Lets sites keep playing embedded audio/video without a tap first.
      AndroidWebViewController.enableDebugging(false);
      androidController.setMediaPlaybackRequiresUserGesture(false);

      // Handles <input type="file"> uploads (documents, camera photos, etc.)
      androidController.setOnShowFileSelector(_onShowFileSelector);
    }

    _controller = controller;
    _controller.loadRequest(Uri.parse(AppConfig.homeUrl));
  }

  /// Opens the native file picker (or camera, for capture-only inputs) when
  /// the web page shows a file upload control, and returns the chosen
  /// file(s) back to the WebView as file:// URIs.
  Future<List<String>> _onShowFileSelector(FileSelectorParams params) async {
    try {
      final result = await FilePicker.platform.pickFiles(
        allowMultiple: params.mode == FileSelectorMode.openMultiple,
        withReadStream: false,
        type: FileType.any,
      );
      if (result == null) return const [];
      return result.files
          .where((f) => f.path != null)
          .map((f) => Uri.file(f.path!).toString())
          .toList();
    } catch (_) {
      return const [];
    }
  }

  FutureOr<NavigationDecision> _handleNavigation(
      NavigationRequest request) async {
    final uri = Uri.tryParse(request.url);
    if (uri == null) return NavigationDecision.navigate;

    // tel:, mailto:, sms:, whatsapp:, intent: -> hand off to the OS.
    if (!uri.scheme.startsWith('http')) {
      await _launchExternally(uri);
      return NavigationDecision.prevent;
    }

    // Direct links to files (invoices, exports, images...) -> download
    // instead of trying to render them inside the WebView.
    final ext = uri.path.contains('.') ? uri.path.split('.').last.toLowerCase() : '';
    if (AppConfig.downloadableExtensions.contains(ext)) {
      _startDownload(request.url);
      return NavigationDecision.prevent;
    }

    // Keep navigation to the admin panel's own domain inside the app.
    final host = uri.host;
    final isAllowedHost = host == AppConfig.allowedHost ||
        AppConfig.allowedSubHosts.any((h) => host.endsWith(h));
    if (isAllowedHost) {
      return NavigationDecision.navigate;
    }

    // Anything else (external links, third-party auth, payment redirects
    // the panel doesn't already whitelist) opens in the system browser.
    await _launchExternally(uri);
    return NavigationDecision.prevent;
  }

  Future<void> _launchExternally(Uri uri) async {
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  void _startDownload(String url) {
    setState(() => _statusMessage = 'Starting download…');
    DownloadHelper.download(
      url: url,
      onStatus: (msg) {
        if (!mounted) return;
        setState(() => _statusMessage = msg);
        Future.delayed(const Duration(seconds: 3), () {
          if (mounted && _statusMessage == msg) {
            setState(() => _statusMessage = null);
          }
        });
      },
    );
  }

  Future<bool> _handleBackButton() async {
    if (await _controller.canGoBack()) {
      await _controller.goBack();
      return false;
    }
    // At the root of the panel: ask before exiting rather than closing
    // instantly on an accidental tap.
    final shouldExit = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Exit app?'),
        content: const Text('Are you sure you want to close the app?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('Exit'),
          ),
        ],
      ),
    );
    return shouldExit ?? false;
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;
        final shouldPop = await _handleBackButton();
        if (shouldPop && mounted) {
          Navigator.of(context).maybePop();
        }
      },
      child: Scaffold(
        body: SafeArea(
          child: Stack(
            children: [
              if (_isOffline)
                _OfflineView(onRetry: () => _controller.reload())
              else if (_hasError)
                _ErrorView(onRetry: () {
                  setState(() => _hasError = false);
                  _controller.reload();
                })
              else
                WebViewWidget(controller: _controller),
              if (_isLoading && !_hasError && !_isOffline)
                LinearProgressIndicator(value: _loadProgress == 0 ? null : _loadProgress),
              if (_statusMessage != null)
                Positioned(
                  left: 16,
                  right: 16,
                  bottom: 16,
                  child: _StatusBanner(message: _statusMessage!),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _StatusBanner extends StatelessWidget {
  const _StatusBanner({required this.message});
  final String message;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Theme.of(context).colorScheme.inverseSurface,
      borderRadius: BorderRadius.circular(8),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        child: Text(
          message,
          style: TextStyle(color: Theme.of(context).colorScheme.onInverseSurface),
        ),
      ),
    );
  }
}

class _OfflineView extends StatelessWidget {
  const _OfflineView({required this.onRetry});
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.wifi_off_rounded, size: 64),
            const SizedBox(height: 16),
            Text('No internet connection', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            const Text(
              'Please check your connection and try again.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            FilledButton(onPressed: onRetry, child: const Text('Retry')),
          ],
        ),
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.onRetry});
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline_rounded, size: 64),
            const SizedBox(height: 16),
            Text('Something went wrong', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            const Text(
              'The page could not be loaded.',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            FilledButton(onPressed: onRetry, child: const Text('Retry')),
          ],
        ),
      ),
    );
  }
}
