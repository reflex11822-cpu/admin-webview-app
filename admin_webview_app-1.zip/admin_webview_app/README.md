# MazagLive Admin — Android WebView App

A Flutter/Android wrapper for **https://admin-pro-mazag.mazaglive.com/** with:

- Persistent login (native WebView cookies survive app restarts)
- File upload from the panel (camera, gallery, documents) via `file_picker`
- File download (invoices, exports, images) saved to the device and opened automatically
- Camera & microphone permission handling for any in-page media features
- Correct Android back-button behaviour (goes back in web history, then confirms before exiting)
- Native splash screen, light/dark mode following the system setting
- Offline / page-error screens with a Retry button
- Release build wired up for a signed, minifiable APK/AAB

```
lib/
  main.dart            – app entry, theme (light/dark)
  app_config.dart       – the URL, allowed domains, download file types
  app_theme.dart         – Material 3 light/dark themes
  webview_screen.dart     – the WebView + all behaviour described above
  download_helper.dart     – downloads a file and opens it
android/                 – standard Flutter Android project (Kotlin, Gradle)
assets/icon/app_icon.png – placeholder app icon/splash image (replace me)
```

## ⚠️ About this deliverable

I generated the **complete, ready-to-open Flutter/Android Studio project**
(all Dart source, Gradle config, manifest, permissions). What I could not do
from this chat environment:

- **Run `flutter pub get` / compile a real APK** — this sandbox has no
  network access to download the Flutter SDK or your project's packages,
  so no binary was actually compiled here.
- **Produce a *signed* APK for you** — signing requires a private keystore
  and passwords that only you should generate and hold. I've wired up the
  Gradle signing config and included the exact commands below; running
  them takes about 5 minutes.

So: open this project in Android Studio (or run the two commands at the
bottom) and it will build normally — nothing further needs to be written,
only executed on a machine with Flutter installed.

## 1. Prerequisites

- [Flutter SDK](https://docs.flutter.dev/get-started/install) 3.22+ installed and on your PATH
- Android Studio (Giraffe or newer) with the Flutter/Dart plugins, **or** just the Android SDK/command-line tools
- JDK 17

## 2. Open the project

```bash
cd admin_webview_app
flutter pub get
```

Then open the folder in Android Studio (`File → Open`), or continue on the command line.

### Replace the placeholder icon

`assets/icon/app_icon.png` is a plain placeholder. Swap in your real 1024×1024
PNG logo, then regenerate the launcher icon and splash screen:

```bash
flutter pub run flutter_launcher_icons
flutter pub run flutter_native_splash:create
```

## 3. Run it in debug mode

```bash
flutter run
```

## 4. Create your release signing key (one-time)

**Keep the keystore file and passwords somewhere safe** — Google Play requires
the *same* key for every future update of this app; losing it means you can
never update the app again under the same listing.

```bash
keytool -genkey -v -keystore ~/admin-panel-release.jks \
  -keyalg RSA -keysize 2048 -validity 10000 -alias admin_panel
```

Then:

```bash
cp android/key.properties.example android/key.properties
```

Edit `android/key.properties` and fill in the real passwords/alias and the
absolute path to the `.jks` file you just created. This file is git-ignored
and is never uploaded anywhere.

## 5. Build the signed release APK

```bash
flutter build apk --release
```

Output: `build/app/outputs/flutter-apk/app-release.apk` — this is signed
with your key and ready to install or distribute.

For the Play Store, build an App Bundle instead:

```bash
flutter build appbundle --release
```

Output: `build/app/outputs/bundle/release/app-release.aab`

## 6. Automated builds with GitHub Actions

`.github/workflows/build-apk.yml` builds a release APK automatically on
every push to `main`, on demand, and creates a downloadable GitHub Release
whenever you push a version tag (`v1.0.0`, etc.).

1. Push this project to a GitHub repository.
2. Add four repository secrets (Settings → Secrets and variables → Actions):
   - `KEYSTORE_BASE64` — your `.jks` file, base64-encoded (`base64 -i admin-panel-release.jks -o keystore.b64`, paste the contents)
   - `KEYSTORE_PASSWORD`
   - `KEY_ALIAS`
   - `KEY_PASSWORD`
3. Push, or tag a release:
   ```bash
   git tag v1.0.0
   git push origin v1.0.0
   ```
4. Get the APK:
   - **Every run**: Actions tab → the workflow run → Artifacts → `app-release-apk`
   - **Tagged runs**: repo's Releases page has the `.apk` attached with a permanent link

Without the four secrets set, the workflow still runs and produces an APK,
but it falls back to debug signing — fine for quick testing, not for
distribution.



- **Domain safety**: only `admin-pro-mazag.mazaglive.com` (and `*.mazaglive.com`)
  load inside the app; any other link (payment gateways, WhatsApp, `tel:`,
  `mailto:`, etc.) opens in the system browser or the relevant app instead.
  Adjust the allow-list in `lib/app_config.dart` if the panel legitimately
  redirects to other domains (e.g. an SSO provider).
- **Application ID**: currently `com.mazaglive.adminpanel`
  (`android/app/build.gradle` → `applicationId`). Change this to your own
  reverse-domain ID before publishing — it cannot be changed after your
  first Play Store upload.
- **App name**: set in `AndroidManifest.xml` (`android:label`) and
  `lib/app_config.dart` (`appName`).
- **minSdkVersion 21** (Android 5.0+), matching the minimum supported by
  the WebView/permission plugins used.
